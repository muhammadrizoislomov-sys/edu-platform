import { create } from "zustand";

interface AppStore {
  activeClass: number;
  activeSubject: number | null;
  setActiveClass: (c: number) => void;
  setActiveSubject: (s: number | null) => void;
}

export const useAppStore = create<AppStore>((set) => ({
  activeClass: 4,
  activeSubject: null,
  setActiveClass: (activeClass) => set({ activeClass }),
  setActiveSubject: (activeSubject) => set({ activeSubject }),
}));
