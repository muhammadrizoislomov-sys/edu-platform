export type Lang = "uz" | "ru";

export const subjects = [
  { id: "math", icon: "🔢", name: { uz: "Matematika", ru: "Математика" }, count: { uz: "800+ material", ru: "800+ материалов" }, color: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  { id: "lang", icon: "📖", name: { uz: "Ona tili", ru: "Родной язык" }, count: { uz: "600+ material", ru: "600+ материалов" }, color: "bg-blue-50 text-blue-700 border-blue-200" },
  { id: "history", icon: "🏛️", name: { uz: "Tarix", ru: "История" }, count: { uz: "450+ material", ru: "450+ материалов" }, color: "bg-amber-50 text-amber-700 border-amber-200" },
  { id: "physics", icon: "⚛️", name: { uz: "Fizika", ru: "Физика" }, count: { uz: "500+ material", ru: "500+ материалов" }, color: "bg-pink-50 text-pink-700 border-pink-200" },
  { id: "chemistry", icon: "🧪", name: { uz: "Kimyo", ru: "Химия" }, count: { uz: "380+ material", ru: "380+ материалов" }, color: "bg-orange-50 text-orange-700 border-orange-200" },
  { id: "biology", icon: "🌿", name: { uz: "Biologiya", ru: "Биология" }, count: { uz: "420+ material", ru: "420+ материалов" }, color: "bg-green-50 text-green-700 border-green-200" },
  { id: "english", icon: "🌍", name: { uz: "Ingliz tili", ru: "Английский" }, count: { uz: "700+ material", ru: "700+ материалов" }, color: "bg-purple-50 text-purple-700 border-purple-200" },
  { id: "it", icon: "💻", name: { uz: "Informatika", ru: "Информатика" }, count: { uz: "350+ material", ru: "350+ материалов" }, color: "bg-teal-50 text-teal-700 border-teal-200" },
];

export const classes = [
  "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"
];

export const materials = {
  interactive: [
    { id: 1, titleUz: "Kasrlar — animatsiyali tushuntirish", titleRu: "Дроби — анимированное объяснение", metaUz: "32 daqiqa · Video + animatsiya", metaRu: "32 минуты · Видео + анимация", badge: { uz: "Yangi", ru: "Новое" }, badgeColor: "bg-emerald-100 text-emerald-700" },
    { id: 2, titleUz: "Ko'paytirish jadvali — interaktiv mashq", titleRu: "Таблица умножения — интерактив", metaUz: "18 daqiqa · Interaktiv", metaRu: "18 минут · Интерактив", badge: { uz: "Mashhur", ru: "Популярное" }, badgeColor: "bg-blue-100 text-blue-700" },
    { id: 3, titleUz: "Geometrik shakllar — 3D ko'rinish", titleRu: "Геометрические фигуры — 3D вид", metaUz: "25 daqiqa · 3D model", metaRu: "25 минут · 3D модель", badge: null, badgeColor: "" },
  ],
  books: [
    { id: 4, titleUz: "Matematika darsligi — 5-sinf (PDF)", titleRu: "Учебник математики — 5 класс (PDF)", metaUz: "248 sahifa · O'zbekcha", metaRu: "248 страниц · Русский", badge: { uz: "Yuklab olish", ru: "Скачать" }, badgeColor: "bg-blue-100 text-blue-700" },
    { id: 5, titleUz: "Mashqlar to'plami — 5-sinf", titleRu: "Сборник упражнений — 5 класс", metaUz: "120 sahifa · PDF", metaRu: "120 страниц · PDF", badge: { uz: "Yuklab olish", ru: "Скачать" }, badgeColor: "bg-blue-100 text-blue-700" },
    { id: 6, titleUz: "O'qituvchi uchun metodik qo'llanma", titleRu: "Методическое пособие для учителя", metaUz: "84 sahifa · PDF", metaRu: "84 страницы · PDF", badge: { uz: "Yangi", ru: "Новое" }, badgeColor: "bg-emerald-100 text-emerald-700" },
  ],
  tests: [
    { id: 7, titleUz: "Kasrlar bo'yicha test (20 savol)", titleRu: "Тест по дробям (20 вопросов)", metaUz: "Qiyinlik: O'rta · 20 daqiqa", metaRu: "Сложность: Средняя · 20 минут", badge: { uz: "Boshlash", ru: "Начать" }, badgeColor: "bg-amber-100 text-amber-700" },
    { id: 8, titleUz: "Arifmetika — tezkor test", titleRu: "Арифметика — быстрый тест", metaUz: "Qiyinlik: Oson · 10 daqiqa", metaRu: "Сложность: Лёгкая · 10 минут", badge: { uz: "Boshlash", ru: "Начать" }, badgeColor: "bg-amber-100 text-amber-700" },
    { id: 9, titleUz: "Yakuniy nazorat ishi", titleRu: "Итоговая контрольная работа", metaUz: "Qiyinlik: Qiyin · 45 daqiqa", metaRu: "Сложность: Трудная · 45 минут", badge: { uz: "Boshlash", ru: "Начать" }, badgeColor: "bg-amber-100 text-amber-700" },
  ],
};

export const games = [
  { id: "word", icon: "🧩", nameUz: "So'z o'yini", nameRu: "Игра слов", descUz: "Lug'at boyitish", descRu: "Обогащение словаря", color: "bg-purple-50 border-purple-200" },
  { id: "math", icon: "🧮", nameUz: "Hisob bellashuvi", nameRu: "Математическое состязание", descUz: "Tez hisoblash", descRu: "Быстрый счёт", color: "bg-emerald-50 border-emerald-200" },
  { id: "geo", icon: "🗺️", nameUz: "Geografiya kvizi", nameRu: "Квиз по географии", descUz: "Mamlakatlar va poytaxtlar", descRu: "Страны и столицы", color: "bg-blue-50 border-blue-200" },
  { id: "chem", icon: "⚗️", nameUz: "Kimyo laboratoriya", nameRu: "Лаборатория химии", descUz: "Virtual tajribalar", descRu: "Виртуальные опыты", color: "bg-orange-50 border-orange-200" },
  { id: "spell", icon: "✍️", nameUz: "Imlo musobaqasi", nameRu: "Диктант-соревнование", descUz: "To'g'ri yozish", descRu: "Правильное написание", color: "bg-green-50 border-green-200" },
  { id: "hist", icon: "🏺", nameUz: "Tarix safari", nameRu: "Путешествие в историю", descUz: "Tarixiy voqealar", descRu: "Исторические события", color: "bg-amber-50 border-amber-200" },
];

export const features = [
  { icon: "📱", titleUz: "Interaktiv darsliklar", titleRu: "Интерактивные учебники", descUz: "Animatsiyali va interaktiv tushuntirishlar", descRu: "Анимированные и интерактивные объяснения" },
  { icon: "✅", titleUz: "Testlar va mashqlar", titleRu: "Тесты и упражнения", descUz: "Bilimingizni sinab ko'ring va natijalarni kuzating", descRu: "Проверьте знания и отслеживайте результаты" },
  { icon: "⬇️", titleUz: "Materiallarni yuklash", titleRu: "Скачивание материалов", descUz: "Dars rejalari va prezentatsiyalarni yuklab oling", descRu: "Планы уроков и презентации" },
  { icon: "👥", titleUz: "O'qituvchilar hamjamiyati", titleRu: "Сообщество учителей", descUz: "Tajribali o'qituvchilar bilan tajriba almashing", descRu: "Делитесь опытом с педагогами" },
  { icon: "🏆", titleUz: "Sertifikatlar", titleRu: "Сертификаты", descUz: "Kurslarni yakunlang va sertifikat oling", descRu: "Завершайте курсы и получайте сертификаты" },
  { icon: "🌐", titleUz: "Ikki tilda", titleRu: "Два языка", descUz: "Materiallar o'zbek va rus tillarida mavjud", descRu: "Материалы на узбекском и русском языках" },
];
