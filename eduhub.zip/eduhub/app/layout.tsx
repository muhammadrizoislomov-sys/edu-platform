import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { LangProvider } from "@/components/LangProvider";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "EduHub — O'qituvchilar uchun ta'lim platformasi",
  description:
    "1-sinfdan 11-sinfgacha barcha fanlar bo'yicha interaktiv darslar, darsliklar, testlar va o'yinlar. Uchun учителей Узбекистана.",
  keywords: ["ta'lim", "o'qituvchi", "darslik", "interaktiv", "test", "eduhub"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="uz" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen bg-background`}
      >
        <LangProvider>{children}</LangProvider>
      </body>
    </html>
  );
}
