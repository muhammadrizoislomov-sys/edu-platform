import { Navbar } from "@/components/layout/Navbar";
import { Hero } from "@/components/sections/Hero";
import { StatsBar } from "@/components/sections/StatsBar";
import { ClassSelector } from "@/components/sections/ClassSelector";
import { SubjectsGrid } from "@/components/sections/SubjectsGrid";
import { GamesSection } from "@/components/sections/GamesSection";
import { FeaturesSection } from "@/components/sections/FeaturesSection";
import { Footer } from "@/components/layout/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-10">
        <Hero />
        <StatsBar />
        <ClassSelector />
        <SubjectsGrid />
        <GamesSection />
        <FeaturesSection />
      </div>
      <Footer />
    </main>
  );
}
