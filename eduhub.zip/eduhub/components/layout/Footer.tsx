"use client";

import { GraduationCap } from "lucide-react";
import { useLang } from "@/components/LangProvider";

export function Footer() {
  const { t } = useLang();
  return (
    <footer id="footer" className="mt-16 bg-muted border-t border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 brand-gradient rounded-lg flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <span className="font-semibold text-lg">EduHub</span>
          </div>
          <p className="text-sm text-muted-foreground text-center">
            {t(
              "O'zbekistondagi o'qituvchilar va o'quvchilar uchun",
              "Для учителей и учеников Узбекистана"
            )}
          </p>
          <div className="flex gap-4 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">{t("Shartlar", "Условия")}</a>
            <a href="#" className="hover:text-foreground transition-colors">{t("Maxfiylik", "Конфиденциальность")}</a>
            <a href="#" className="hover:text-foreground transition-colors">{t("Aloqa", "Контакты")}</a>
          </div>
        </div>
        <div className="mt-6 text-center text-xs text-muted-foreground">
          © 2024 EduHub. {t("Barcha huquqlar himoyalangan.", "Все права защищены.")}
        </div>
      </div>
    </footer>
  );
}
