"use client";

import { useState } from "react";
import { GraduationCap, Gamepad2, BookOpen, Users, Info, Menu, X } from "lucide-react";
import { useLang } from "@/components/LangProvider";
import { cn } from "@/lib/utils";

export function Navbar() {
  const { lang, setLang, t } = useLang();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { icon: BookOpen, labelUz: "Kurslar", labelRu: "Курсы", href: "#subjects" },
    { icon: Gamepad2, labelUz: "O'yinlar", labelRu: "Игры", href: "#games", highlight: true },
    { icon: Users, labelUz: "O'qituvchilar", labelRu: "Учителя", href: "#features" },
    { icon: Info, labelUz: "Haqida", labelRu: "О нас", href: "#footer" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-border shadow-sm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2 font-semibold text-lg text-foreground">
            <div className="w-8 h-8 brand-gradient rounded-lg flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <span>EduHub</span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                  item.highlight
                    ? "text-emerald-600 bg-emerald-50 hover:bg-emerald-100"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                <item.icon className="w-4 h-4" />
                {t(item.labelUz, item.labelRu)}
              </a>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {/* Language toggle */}
            <div className="flex items-center gap-1 bg-muted rounded-lg p-1">
              {(["uz", "ru"] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={cn(
                    "px-3 py-1 rounded-md text-xs font-semibold transition-all",
                    lang === l
                      ? "bg-white text-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {l === "uz" ? "O'z" : "Рус"}
                </button>
              ))}
            </div>

            {/* Register button */}
            <button className="hidden sm:block brand-gradient text-white px-4 py-2 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity">
              {t("Ro'yxatdan o'tish", "Регистрация")}
            </button>

            {/* Mobile menu toggle */}
            <button
              className="md:hidden p-2 rounded-lg text-muted-foreground hover:bg-muted"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-border bg-white px-4 py-3 space-y-1">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={cn(
                "flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium",
                item.highlight
                  ? "text-emerald-600 bg-emerald-50"
                  : "text-muted-foreground hover:bg-muted"
              )}
            >
              <item.icon className="w-4 h-4" />
              {t(item.labelUz, item.labelRu)}
            </a>
          ))}
          <div className="pt-2">
            <button className="w-full brand-gradient text-white px-4 py-2.5 rounded-lg text-sm font-medium">
              {t("Ro'yxatdan o'tish", "Регистрация")}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
