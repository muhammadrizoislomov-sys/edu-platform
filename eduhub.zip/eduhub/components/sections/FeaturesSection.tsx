"use client";

import { useLang } from "@/components/LangProvider";
import { features } from "@/lib/data";

export function FeaturesSection() {
  const { lang, t } = useLang();

  return (
    <section id="features">
      <h2 className="text-lg font-semibold mb-1">
        {t("Nima uchun EduHub?", "Почему EduHub?")}
      </h2>
      <p className="text-sm text-muted-foreground mb-5">
        {t(
          "O'qituvchilar va o'quvchilar uchun zamonaviy platforma",
          "Современная платформа для учителей и учеников"
        )}
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map((f, i) => (
          <div
            key={i}
            className="bg-background border border-border rounded-xl p-5 hover:border-emerald-200 hover:shadow-sm transition-all"
          >
            <div className="text-2xl mb-3">{f.icon}</div>
            <div className="text-sm font-semibold mb-1.5">
              {lang === "uz" ? f.titleUz : f.titleRu}
            </div>
            <div className="text-xs text-muted-foreground leading-relaxed">
              {lang === "uz" ? f.descUz : f.descRu}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
