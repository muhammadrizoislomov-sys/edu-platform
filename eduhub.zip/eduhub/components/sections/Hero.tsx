"use client";

import { useLang } from "@/components/LangProvider";

export function Hero() {
  const { t } = useLang();
  return (
    <section className="brand-gradient rounded-2xl px-8 py-14 text-center text-white relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full bg-white/5 pointer-events-none" />
      <div className="absolute -bottom-16 -left-8 w-64 h-64 rounded-full bg-white/4 pointer-events-none" />

      <div className="relative z-10 max-w-2xl mx-auto">
        <span className="inline-block bg-white/20 text-white text-xs font-semibold px-4 py-1.5 rounded-full mb-5 backdrop-blur-sm">
          🇺🇿 {t("O'zbekiston uchun #1 ta'lim platformasi", "#1 образовательная платформа Узбекистана")}
        </span>

        <h1 className="text-3xl sm:text-4xl font-bold leading-tight mb-4">
          {t(
            "O'qituvchilar uchun barcha materiallar bir joyda",
            "Все материалы для учителей в одном месте"
          )}
        </h1>
        <p className="text-white/85 text-base sm:text-lg leading-relaxed mb-8">
          {t(
            "1-sinfdan 11-sinfgacha interaktiv darslar, darsliklar, testlar va o'yinlar",
            "Интерактивные уроки, учебники, тесты и игры с 1 по 11 класс"
          )}
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <a
            href="#subjects"
            className="bg-white text-emerald-700 font-semibold px-7 py-3 rounded-xl hover:bg-white/90 transition-all text-sm"
          >
            {t("Boshlash →", "Начать →")}
          </a>
          <a
            href="#features"
            className="border border-white/50 text-white font-medium px-7 py-3 rounded-xl hover:bg-white/10 transition-all text-sm"
          >
            {t("Ko'proq bilish", "Узнать больше")}
          </a>
        </div>
      </div>
    </section>
  );
}
