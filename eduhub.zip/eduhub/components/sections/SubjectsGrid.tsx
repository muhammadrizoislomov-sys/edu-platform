"use client";

import { useRef, useEffect } from "react";
import { useLang } from "@/components/LangProvider";
import { useAppStore } from "@/lib/store";
import { subjects, materials, classes } from "@/lib/data";
import { cn } from "@/lib/utils";
import { ContentPanel } from "@/components/ui/ContentPanel";

export function SubjectsGrid() {
  const { lang, t } = useLang();
  const { activeClass, activeSubject, setActiveSubject } = useAppStore();
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeSubject !== null && panelRef.current) {
      setTimeout(() => {
        panelRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }, 100);
    }
  }, [activeSubject]);

  const className = lang === "uz"
    ? `${classes[activeClass]}-sinf`
    : `${classes[activeClass]} класс`;

  return (
    <section id="subjects">
      <h2 className="text-lg font-semibold mb-1">
        {t("Fanni tanlang", "Выберите предмет")}
      </h2>
      <p className="text-sm text-muted-foreground mb-4">
        {t("Fan kartasini bosing va materiallarni ko'ring", "Нажмите на карточку предмета")}
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {subjects.map((s, i) => (
          <button
            key={s.id}
            onClick={() => setActiveSubject(activeSubject === i ? null : i)}
            className={cn(
              "flex flex-col items-center p-4 rounded-xl border text-center transition-all hover:shadow-sm",
              activeSubject === i
                ? "border-emerald-400 bg-emerald-50 shadow-sm"
                : "border-border bg-background hover:border-emerald-300"
            )}
          >
            <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center text-xl mb-2.5", s.color)}>
              {s.icon}
            </div>
            <div className="text-sm font-medium leading-tight">{s.name[lang]}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{s.count[lang]}</div>
          </button>
        ))}
      </div>

      {activeSubject !== null && (
        <div ref={panelRef} className="animate-fade-in">
          <ContentPanel
            heading={`${className} · ${subjects[activeSubject].name[lang]}`}
            materials={materials}
            lang={lang}
          />
        </div>
      )}
    </section>
  );
}
