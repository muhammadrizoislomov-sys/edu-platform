"use client";

import { useLang } from "@/components/LangProvider";

export function StatsBar() {
  const { t } = useLang();
  const stats = [
    { num: "11", label: t("Sinf darajasi", "Уровней классов") },
    { num: "20+", label: t("Fan yo'nalishlari", "Предметов") },
    { num: "5 000+", label: t("Interaktiv material", "Интерактивных материалов") },
    { num: "2", label: t("Til (O'z / Rus)", "Языка (Уз / Рус)") },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((s) => (
        <div key={s.label} className="bg-muted rounded-xl p-5 text-center">
          <div className="text-2xl font-bold text-emerald-600">{s.num}</div>
          <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
        </div>
      ))}
    </div>
  );
}
