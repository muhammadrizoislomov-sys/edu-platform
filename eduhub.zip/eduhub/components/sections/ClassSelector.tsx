"use client";

import { useAppStore } from "@/lib/store";
import { useLang } from "@/components/LangProvider";
import { classes } from "@/lib/data";
import { cn } from "@/lib/utils";

export function ClassSelector() {
  const { lang, t } = useLang();
  const { activeClass, setActiveClass, setActiveSubject } = useAppStore();

  return (
    <section>
      <h2 className="text-lg font-semibold mb-1">
        {t("Sinf darajasini tanlang", "Выберите класс")}
      </h2>
      <p className="text-sm text-muted-foreground mb-4">
        {t("Sinfni bosing — materiallar filtrlangadi", "Нажмите на класс — материалы отфильтруются")}
      </p>
      <div className="flex flex-wrap gap-2">
        {classes.map((c, i) => (
          <button
            key={c}
            onClick={() => { setActiveClass(i); setActiveSubject(null); }}
            className={cn(
              "px-4 py-2 rounded-full text-sm font-medium border transition-all",
              activeClass === i
                ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                : "bg-background text-muted-foreground border-border hover:border-emerald-400 hover:text-emerald-600"
            )}
          >
            {lang === "uz" ? `${c}-sinf` : `${c} класс`}
          </button>
        ))}
      </div>
    </section>
  );
}
