"use client";

import { useLang } from "@/components/LangProvider";
import { games } from "@/lib/data";
import { cn } from "@/lib/utils";

export function GamesSection() {
  const { lang, t } = useLang();

  return (
    <section id="games">
      <div className="flex items-center gap-2 mb-1">
        <span className="text-xl">🎮</span>
        <h2 className="text-lg font-semibold">
          {t("O'quv o'yinlari", "Учебные игры")}
        </h2>
        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
          {t("Yangi", "Новое")}
        </span>
      </div>
      <p className="text-sm text-muted-foreground mb-5">
        {t(
          "O'yin orqali bilim olish — qiziqarli va samarali",
          "Обучение через игру — интересно и эффективно"
        )}
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {games.map((g) => (
          <button
            key={g.id}
            className={cn(
              "flex flex-col items-center text-center p-5 rounded-xl border transition-all hover:shadow-md hover:-translate-y-0.5 cursor-pointer",
              g.color
            )}
          >
            <span className="text-3xl mb-3">{g.icon}</span>
            <div className="text-sm font-semibold mb-1">
              {lang === "uz" ? g.nameUz : g.nameRu}
            </div>
            <div className="text-xs text-muted-foreground leading-snug">
              {lang === "uz" ? g.descUz : g.descRu}
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}
