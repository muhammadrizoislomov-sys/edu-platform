"use client";

import { useState } from "react";
import { Tablet, BookOpen, ClipboardCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Lang } from "@/lib/data";

interface Material {
  id: number;
  titleUz: string;
  titleRu: string;
  metaUz: string;
  metaRu: string;
  badge: { uz: string; ru: string } | null;
  badgeColor: string;
}

interface MaterialsData {
  interactive: Material[];
  books: Material[];
  tests: Material[];
}

interface Props {
  heading: string;
  materials: MaterialsData;
  lang: Lang;
}

type TabKey = "interactive" | "books" | "tests";

const tabs: { key: TabKey; labelUz: string; labelRu: string; icon: typeof Tablet }[] = [
  { key: "interactive", labelUz: "Interaktiv darslar", labelRu: "Интерактивные уроки", icon: Tablet },
  { key: "books", labelUz: "Darsliklar", labelRu: "Учебники", icon: BookOpen },
  { key: "tests", labelUz: "Testlar", labelRu: "Тесты", icon: ClipboardCheck },
];

const tabIcons: Record<TabKey, { bg: string; color: string }> = {
  interactive: { bg: "bg-emerald-50", color: "text-emerald-600" },
  books: { bg: "bg-blue-50", color: "text-blue-600" },
  tests: { bg: "bg-amber-50", color: "text-amber-600" },
};

export function ContentPanel({ heading, materials, lang }: Props) {
  const [activeTab, setActiveTab] = useState<TabKey>("interactive");

  const t = (uz: string, ru: string) => (lang === "uz" ? uz : ru);
  const mats = materials[activeTab];
  const { bg, color } = tabIcons[activeTab];

  return (
    <div className="bg-background border border-border rounded-2xl overflow-hidden shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-border">
        <div className="flex items-center gap-2 font-medium text-sm">
          <BookOpen className="w-4 h-4 text-emerald-600" />
          {heading}
        </div>
        {/* Tabs */}
        <div className="flex gap-1 flex-wrap">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all",
                activeTab === tab.key
                  ? "bg-emerald-600 text-white border-emerald-600"
                  : "border-border text-muted-foreground hover:border-emerald-300 hover:text-emerald-600"
              )}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {t(tab.labelUz, tab.labelRu)}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-3 tab-panel-enter">
        {mats.map((m) => {
          const Icon = tabs.find((t) => t.key === activeTab)!.icon;
          return (
            <div
              key={m.id}
              className="flex items-center gap-3 p-3.5 rounded-xl border border-border bg-muted/40 hover:border-emerald-300 hover:bg-emerald-50/30 cursor-pointer transition-all group"
            >
              <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0", bg)}>
                <Icon className={cn("w-5 h-5", color)} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate group-hover:text-emerald-700 transition-colors">
                  {t(m.titleUz, m.titleRu)}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">{t(m.metaUz, m.metaRu)}</div>
              </div>
              {m.badge && (
                <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full flex-shrink-0", m.badgeColor)}>
                  {t(m.badge.uz, m.badge.ru)}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
