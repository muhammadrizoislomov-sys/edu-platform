"use client";

import { createContext, useContext, useState, ReactNode } from "react";
import type { Lang } from "@/lib/data";

interface LangContextType {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (uz: string, ru: string) => string;
}

const LangContext = createContext<LangContextType>({
  lang: "uz",
  setLang: () => {},
  t: (uz) => uz,
});

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("uz");
  const t = (uz: string, ru: string) => (lang === "uz" ? uz : ru);
  return (
    <LangContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  return useContext(LangContext);
}
